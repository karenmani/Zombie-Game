package cs2113.zombies;
import cs2113.util.Helper;
import java.awt.*;

public class Zombie {
    private int x;
    private int y;
    private int dir;

    public Zombie(int x, int y) {
        this.x = x;
        this.y = y;
        dir = Helper.nextInt(4);
    }

    public void drawZombie() {
        ZombieSim.dp.setPenColor(Color.BLUE);
        ZombieSim.dp.drawDot(x, y);
    } //draws blue dot for zombie

    public void updateZombie(City city) {
        moving(city);
    }

    void moving(City city) {
        if(Helper.nextDouble() <=0.2) {
            dir=Helper.nextInt(4);
        }

        int X = x;
        int Y = y;
        if(dir==0) { //north
            X=x-1;
        }
        else if(dir==1) { //east
            Y=y-1;
        }
        else if(dir==2) { //south
            X=x+1;
        }
        else if(dir==3) { //west
            Y=y+1;
        }
        else {
            System.out.println("ERROR");
            System.exit(-1);
        }

        if(city.noWall(X, Y)) {
            x=X;
            y=Y;
        }
        else {
            dir=Helper.nextInt(4);
        }
    }
}
